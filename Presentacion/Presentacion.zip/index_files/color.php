	.breadcrumb.women{
		background-image: url(http://shinetheme.com/demosd/glammy/wp-content/uploads/2014/04/breadcrumb_bg1.jpg);
	}
	.breadcrumb{
		background-image: url(http://shinetheme.com/demosd/glammy/wp-content/uploads/2014/04/breadcrumb_bg2.jpg);
	}
	.my_account{
		background-image: url(http://shinetheme.com/demosd/glammy/wp-content/uploads/2014/04/my_account_bg.jpg);
	}
	.update_page{
		background-image: url(http://shinetheme.com/demosd/glammy/wp-content/uploads/2014/04/update_bg.jpg);
	}
	.page404{
		background-image: url(http://shinetheme.com/demosd/glammy/wp-content/uploads/2014/04/404_bg.jpg);
	}
                    #header{
margin: 0 auto;
}
/*.navmenu li a{padding: 26px 15px!important;}
header > div#undefined-sticky-wrapper, .menu_block{ height: 80px!important;}*/                .recent_post_date{
	background-color: #333333;
}
a:hover, a:focus,
.widget_categories li a:hover, .product-categories li a:hover, .widget_archive li a:hover,
.post_meta li:hover i, .post_meta li:hover .sep{
	color: #333333;
}
.pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus, .pagination .current:hover{
	border-color: #333333;
	background-color: #333333;
}
.pagination li a:hover, .pagination li.active a, .pagination .current, .jCarousel_pagination a:hover{
	color: #333333;
	border-color: #333333;
}
a.slide_banner:before{
	border-color: #333333;
}
.tovar_item_btns a:hover	 {
	background-color: #333333;
	border-color: #333333;
}
.shopping_bag .shopping_bag_btn:hover:before, .shopping_bag .shopping_bag_btn:hover:after, .navmenu li:hover a:before,
.navmenu li.active a:before,
.navmenu li:hover a:after,
.navmenu li.active a:after, .navmenu > li.current-menu-ancestor:after,
.navmenu > li.current-menu-ancestor:before,.navmenu > li.current-menu-item:after,
.navmenu > li.current-menu-item:before{
	background-color: #333333;
	content:'';
	position:absolute;
	left:-1px;
	right:-1px;
	top:-2px;
	height:2px;
}
.navmenu > li.current-menu-item:after, .navmenu li:hover a:after, .shopping_bag .shopping_bag_btn:hover:after,
.navmenu > li.current-menu-ancestor:after{
	top:auto; bottom:-2px;
}
.navmenu li.menu-item-has-children ul li.active a,
.navmenu li.menu-item-has-children ul li a:hover, .mega_menu .current-menu-item  a, .navmenu li.menu-item-has-children ul li.current-menu-item a,
.navmenu li.menu-item-has-children ul li.current-menu-item a:before, 
.navmenu li.menu-item-has-children ul li.active a:before,
.navmenu li.menu-item-has-children ul li a:hover:before{
	color: #333333;
}
/*.navmenu li.menu-item-has-children:hover:before{
	background-color: #333333;
}*/

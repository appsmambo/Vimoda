<?php
// Where will you get the forms' results?
define("CONTACT_FORM", 'crazyshrimp13@gmail.com');
?>